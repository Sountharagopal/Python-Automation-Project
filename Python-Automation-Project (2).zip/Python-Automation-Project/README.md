# 🚀 Python Data Automation Script
<p align="center">
  <!-- Animated banner (local file stored in assets/banner.gif) -->
  <img src="assets/banner.gif" alt="Automation banner" width="900px">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.10+-blue.svg" alt="Python">
  <img src="https://img.shields.io/badge/Library-Pandas-yellow.svg" alt="Pandas">
  <img src="https://img.shields.io/badge/Status-Complete-success.svg" alt="Status">
  <img src="https://img.shields.io/badge/Made%20By-Sounthar-red.svg" alt="Author">
</p>

---

## 🌈 Animated Theme — Light / Dark Preview
Use the two screenshots below to show how the tool / output looks in light and dark modes. Store images in `assets/` and reference them like below.

<p align="center">
  <img src="assets/screenshot-light.png" alt="Light Mode Preview" width="420px" style="margin-right:10px;">
  <img src="assets/screenshot-dark.png" alt="Dark Mode Preview" width="420px">
</p>

---

## 🔥 Live Demo (GIF)
<p align="center">
  <!-- Demo GIF showing the script running -->
  <img src="assets/demo.gif" alt="Demo running" width="700px">
</p>

---

## ✨ What it does
- Reads large CSV (5000+ rows)  
- Cleans whitespace, normalizes dates, validates emails  
- Removes duplicates and missing-value handling  
- Exports `cleaned_data.csv`, `cleaned_data.xlsx`, and `report.txt`  
- One-click run via `setup.bat`

---


