"""
---------------------------------------------------------
Python Data Cleaning & Automation Script
Author  : Sounthar (student)
Purpose : Automate cleaning of bulk CSV data (5000+ rows)
Result  : Generates cleaned dataset + summary report (CSV, Excel, TXT)
---------------------------------------------------------
"""

import pandas as pd
import os
from datetime import datetime
import re

# ------------------------------ CONFIG ------------------------------
INPUT_FILE = os.path.join("data", "raw_data.csv")
CLEANED_CSV = os.path.join("output", "cleaned_data.csv")
CLEANED_XLSX = os.path.join("output", "cleaned_data.xlsx")
REPORT_FILE = os.path.join("output", "report.txt")

# Basic email validation regex (simple, not exhaustive)
EMAIL_REGEX = re.compile(r"[^@]+@[^@]+\.[^@]+")


# ------------------------------ HELPERS ------------------------------
def ensure_output_folder():
    os.makedirs("output", exist_ok=True)


def is_valid_email(email):
    """Return True if email looks valid, else False."""
    if not isinstance(email, str) or email.strip().upper() in ("", "N/A"):
        return False
    return EMAIL_REGEX.match(email.strip()) is not None


def safe_to_str(val):
    """Convert non-null values to string for string operations."""
    if pd.isna(val):
        return ""
    return str(val)


# ------------------------------ LOAD ------------------------------
def load_dataset(path):
    print(f"📂 Loading dataset from: {path}")
    df = pd.read_csv(path, dtype=str)  # read everything as string to avoid early parsing issues
    print(f"✔ Loaded {len(df)} rows and {len(df.columns)} columns.")
    return df


# ------------------------------ CLEAN ------------------------------
def clean_dataset(df):
    """
    - Trim whitespace
    - Uniform case for Name
    - Validate/normalize emails
    - Standardize Date to YYYY-MM-DD when possible
    - Standardize Status field
    - Convert numeric-like columns to appropriate types if possible (Amount)
    - Remove exact duplicate rows
    """

    original_count = len(df)
    actions = {
        "filled_missing": 0,
        "invalid_emails": 0,
        "fixed_dates": 0,
        "duplicates_removed": 0,
        "empty_rows_removed": 0
    }

    # Trim whitespace from all string values
    df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    # Replace empty strings with NaN to handle missing uniformly
    df.replace({"": pd.NA, "N/A": pd.NA, "n/a": pd.NA}, inplace=True)

    # Drop rows that are completely empty
    before = len(df)
    df.dropna(how="all", inplace=True)
    actions["empty_rows_removed"] = before - len(df)

    # Standardize Name column (Title Case) if exists
    if "Name" in df.columns:
        df["Name"] = df["Name"].fillna("").apply(lambda x: safe_to_str(x).title().strip() if x != "" else pd.NA)

    # Email cleaning & validation
    if "Email" in df.columns:
        def clean_email(e):
            e_str = safe_to_str(e).lower().strip()
            # Quick fix: replace double @@ or spaces
            e_str = e_str.replace(" ", "").replace("@@", "@")
            if e_str == "":
                return pd.NA
            if not EMAIL_REGEX.match(e_str):
                return e_str  # keep it but mark as invalid in report
            return e_str
        df["Email"] = df["Email"].apply(clean_email)
        actions["invalid_emails"] = df["Email"].apply(lambda x: 0 if (not pd.isna(x) and EMAIL_REGEX.match(str(x))) else 1).sum()

    # Date standardization to YYYY-MM-DD (tries several common formats)
    if "Date" in df.columns:
        def parse_date(val):
            vs = safe_to_str(val)
            if vs == "" or pd.isna(val):
                return pd.NA
            for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d", "%d %b %Y", "%d %B %Y"):
                try:
                    dt = datetime.strptime(vs, fmt)
                    return dt.strftime("%Y-%m-%d")
                except Exception:
                    continue
            # Try pandas parser as last resort
            try:
                dt = pd.to_datetime(vs, dayfirst=True, errors="coerce")
                if pd.isna(dt):
                    return vs  # return original if unparseable
                return dt.strftime("%Y-%m-%d")
            except Exception:
                return vs

        df["Date"] = df["Date"].apply(parse_date)
        # count how many look like YYYY-MM-DD (simple heuristic)
        actions["fixed_dates"] = df["Date"].apply(lambda x: 1 if isinstance(x, str) and re.match(r"\d{4}-\d{2}-\d{2}", x) else 0).sum()

    # Status normalization (example: Active / Inactive)
    if "Status" in df.columns:
        df["Status"] = df["Status"].fillna("").apply(lambda s: safe_to_str(s).strip().title() if s != "" else pd.NA)
        df["Status"] = df["Status"].replace({"Act": "Active", "Inactive": "Inactive", "Active": "Active"})

    # Numeric column normalization (Amount) - try convert
    if "Amount" in df.columns:
        def clean_amount(a):
            s = safe_to_str(a).replace(",", "").strip()
            if s == "" or s.upper() == "N/A":
                return pd.NA
            try:
                # if decimal present -> float, else int
                if "." in s:
                    return float(s)
                return int(s)
            except Exception:
                try:
                    return float(s)
                except Exception:
                    return pd.NA
        df["Amount"] = df["Amount"].apply(clean_amount)

    # Remove exact duplicates
    before_dup = len(df)
    df.drop_duplicates(keep="first", inplace=True)
    actions["duplicates_removed"] = before_dup - len(df)

    # Fill some remaining missing basics with "N/A" (optional)
    df.fillna("N/A", inplace=True)
    actions["filled_missing"] = df.isna().sum().sum()  # should be zero after fill; fallback metric

    final_count = len(df)
    summary = {
        "original_rows": original_count,
        "final_rows": final_count,
        "rows_removed": original_count - final_count,
        "actions": actions
    }
    return df, summary


# ------------------------------ SAVE & REPORT ------------------------------
def save_outputs(df, summary):
    ensure_output_folder()

    # Save CSV
    df.to_csv(CLEANED_CSV, index=False)

    # Save Excel for convenience
    try:
        df.to_excel(CLEANED_XLSX, index=False, engine="openpyxl")
    except Exception:
        # if openpyxl is missing, skip silently
        pass

    # Generate a human readable text report
    report_lines = []
    report_lines.append("---------------------------------------------------------")
    report_lines.append("DATA CLEANING REPORT")
    report_lines.append("---------------------------------------------------------")
    report_lines.append(f"Generated On: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report_lines.append(f"Original Rows: {summary['original_rows']}")
    report_lines.append(f"Final Rows   : {summary['final_rows']}")
    report_lines.append(f"Rows Removed : {summary['rows_removed']}")
    report_lines.append("")
    report_lines.append("Actions detail:")
    for k, v in summary["actions"].items():
        report_lines.append(f"- {k.replace('_', ' ').title()}: {v}")
    report_lines.append("")
    report_lines.append(f"Files exported:")
    report_lines.append(f"- {CLEANED_CSV}")
    report_lines.append(f"- {CLEANED_XLSX} (if openpyxl installed)")
    report_lines.append("---------------------------------------------------------")

    with open(REPORT_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))

    print(f"💾 Cleaned CSV saved: {CLEANED_CSV}")
    print(f"📄 Report saved: {REPORT_FILE}")


# ------------------------------ MAIN ------------------------------
def main():
    ensure_output_folder()

    if not os.path.exists(INPUT_FILE):
        print(f"❌ Input file not found: {INPUT_FILE}")
        return

    df = load_dataset(INPUT_FILE)
    cleaned_df, summary = clean_dataset(df)
    save_outputs(cleaned_df, summary)
    print("\n🎉 Data cleaning completed successfully!")
    print(f"Rows before: {summary['original_rows']} | Rows after: {summary['final_rows']}")


if __name__ == "__main__":
    main()
